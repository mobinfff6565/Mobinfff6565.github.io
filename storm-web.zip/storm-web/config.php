<?php

$CONFIG = array (
    "mobinfff6565" => [
        "fullname" => "hacker", 
        "password" => "mobin13851361",
    ], 
    
);

?>
